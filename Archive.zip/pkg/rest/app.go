package rest

import (
	"github.com/gorilla/mux"
	"log"
	"net/http"
)

type App struct {
	Router *mux.Router
}

func (a *App) Run(addr string) {
	log.Fatal(http.ListenAndServe(addr, a.Router))
}

func (a *App) Initialize() {
	a.Router = mux.NewRouter()
	a.initializeRoutes()
}

func (a *App) initializeRoutes() {
	// Loop through list of endpoints
	// Replace path and type of request

	a.Router.HandleFunc("/endpoint-1", func(writer http.ResponseWriter, request *http.Request) {
		writer.Write([]byte("Ready"))
	}).Methods("POST")

	//If Function name is provided, use the function name instead of the shorthand function
	a.Router.HandleFunc("/endpoint-2", functionName2).Methods("POST")

	a.Router.HandleFunc("/endpoint-3", func(writer http.ResponseWriter, request *http.Request) {
		writer.Write([]byte("Ready"))
	}).Methods("POST")

}
