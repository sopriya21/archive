// Create this only if function name is provided for any path
package rest

import "net/http"

// Loop through the paths and render the function name here
func functionName1(writer http.ResponseWriter, request *http.Request) {
	writer.Write([]byte("Ready"))
}
