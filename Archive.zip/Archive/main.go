package main

//Replace 'ApiTemplate' with project name
import "{{ApiTemplate}}/pkg/rest"

func main() {
	app := rest.App{}
	app.Initialize()
	app.Run("{{port}}")
}
