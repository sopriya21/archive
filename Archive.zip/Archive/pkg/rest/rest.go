// Create this only if function name is provided for any path
{{#if endpoints.functionName}}
package rest

import "net/http"

// Loop through the paths and render the function name here
{{#each endpoints}}
{{#if functionName}}
func {{this.functionName}}(writer http.ResponseWriter, request *http.Request) {
	writer.Write([]byte("Ready"))
}
{{/if}}
{{/each}}

{{/if}}

