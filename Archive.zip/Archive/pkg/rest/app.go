package rest

import (
	"github.com/gorilla/mux"
	"log"
	"net/http"
)

type App struct {
	Router *mux.Router
}

func (a *App) Run(addr string) {
	log.Fatal(http.ListenAndServe(addr, a.Router))
}

func (a *App) Initialize() {
	a.Router = mux.NewRouter()
	a.initializeRoutes()
}

func (a *App) initializeRoutes() {
	// Loop through list of endpoints
	// Replace path and type of request

	{{#each endpoints}}
	{{#if this.functionName}} 
	a.Router.HandleFunc("/{{this.path}}", {{this.functionName}}.Methods("{{this.request}}"))
	{{else}}
	a.Router.HandleFunc("/{{this.path}}", func(writer http.ResponseWriter, request *http.Request) {
		writer.Write([]byte("Ready"))
	}).Methods("{{this.request}}")
	{{/if}}
	{{/each}}


}
